#include "Matrix.h"

#include <iostream>
//#include <pthread>

using namespace std;

int main()
{
	string input1;
	string input2;

	cout << "Welcome to the matrix multipler!" << endl 
		<< "Please enter the name of your first matrix: ";

	cin >> input1;

	cout << "\nPlease enter the name of your second matrix: ";

	cin >> input2;

	cout << "Your first file is " << input1 << "and your second file is " 
		<< input2 << endl;



}
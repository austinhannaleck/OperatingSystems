#include "MemoryManager.h"

int main()
{
	MemoryManager m("numbers.txt");
}